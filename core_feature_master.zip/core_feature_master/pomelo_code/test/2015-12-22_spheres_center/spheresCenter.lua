positionfile = "../test/2015-12-22_spheres_center/ellipsoids_linear_std5.ellip"
readfile = "../test/2015-12-22_spheres_center/read.lua"

xmin = 0
ymin = 0
zmin = 0

xmax = 1132
ymax = 1132
zmax = 1000

epsilon = 1e-6

boundary = "none"

postprocessing = true
savesurface = true
savereduced = true
savepoly = true

