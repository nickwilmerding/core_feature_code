
s = {}

function docalculation (p) 
    p:addpoint(1, -1, 0, 0)
    p:addpoint(2, 1, 0, 0)
end
