positionfile = "../test/2016-03-23_niceImages/pos.txt"
readfile = "../test/2016-03-23_niceImages/read.lua"

xmin = -10
ymin = -10
zmin = -10

xmax = 10
ymax = 10
zmax = 10

boundary = "none"
postprocessing = false

savepoly = true
saveoff = true
savereduced = true
savesurface = true
