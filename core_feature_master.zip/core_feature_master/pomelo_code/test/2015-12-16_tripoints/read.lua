
s = {}

function docalculation (p) 
    p:addpoint(1, -1, 0, 0)
    p:addpoint(2, 0, 0, 0)
    p:addpoint(1, 1, 0, 0)
--    p:addpoint(0, 1, 0, 4)
--    p:addpoint(1, 1, 1, 5)
--    p:addpoint(0, 0.873, -0.31, 6)
--    p:addpoint(0.111, -0.23, 0.43, 7)
end
