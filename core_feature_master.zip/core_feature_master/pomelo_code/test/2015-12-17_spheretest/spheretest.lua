positionfile = "../test/2015-12-17_spheretest/ellipsoids_linear_std5.ellip"
readfile = "../test/2015-12-17_spheretest/read.lua"

xmin = 40
ymin = 43
zmin = 27

xmax = 1090
ymax = 1089
zmax = 975

epsilon = 1e-6

boundary = "periodic"

xpbc = false
ypbc = false
zpbc = false
savepoly = true
savereduced = true
savesurface = true
