positionfile = "../test/2015-12-14_input_test/pos.txt"
readfile = "../test/2015-12-14_input_test/read.lua"

xmin = -5.0
ymin = -5.0
zmin = -5.0

xmax = 5.0
ymax = 5.0
zmax = 5.0

epsilon = 1e-6

boundary = "none"

postprocessing = false
savepoly = true
savereduced = true
savesurface = true
