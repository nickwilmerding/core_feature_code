
import os, sys
import glob as glob

a = glob.glob('*.txt')
print(len(a))
f = open('tasklist.sh','w')


for file in a:
	pdbname = file
	Filein = '/home/atg25/project/casp12/casp12_2.0_predictions/859/pomelo_vor/vor_cal'+pdbname+'_param.lua'
	f.write('mkdir '+'/home/atg25/project/casp12/casp12_2.0_predictions/859/pomelo_vor/vor_cal'+pdbname+'_result\n')
	f.write('./pomelo -mode GENERIC -i '+Filein+' -o /home/atg25/project/casp12/casp12_2.0_predictions/859/pomelo_vor/vor_cal'+pdbname+'_result\n')
# pdbname = str(sys.argv[1])
# os.system('mkdir '+'/ysm-gpfs/home/zm73/scratch60/residue_packing/'+pdbname+'_result')
# Filein = '/ysm-gpfs/home/zm73/scratch60/residue_packing/'+pdbname + '.lua'

# os.system('./pomelo -mode GENERIC -i '+Filein+' -o /ysm-gpfs/home/zm73/scratch60/residue_packing/'+pdbname+'_result')
# os.rename('/ysm-gpfs/home/zm73/scratch60/residue_packing/'+pdbname+'_result/setVoronoiNeighbours.dat','/ysm-gpfs/home/zm73/scratch60/residue_packing/'+pdbname+'_result/'+pdbname+'_setVoronoiNeighbours.dat')





