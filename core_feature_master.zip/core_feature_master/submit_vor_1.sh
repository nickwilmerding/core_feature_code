#!/bin/bash
#SBATCH --partition=scavenge
#SBATCH --job-name=vor_1
#SBATCH --array=1-1001
#SBATCH -N 1 # one node
#SBATCH -c 1 # one CPUs/task
#SBATCH -e submit_vor_1.error
#SBATCH -o submit_vor_1.out
#SBATCH --mem-per-cpu=6400
#SBATCH --time=23:59:00
#SBATCH --requeue
# run the command

module load GCCcore/6.4.0

cd $SLURM_SUBMIT_DIR
sed -n "${SLURM_ARRAY_TASK_ID}p" ./output_vor/tasklist.sh | /bin/bash


