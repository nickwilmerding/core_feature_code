import os
import sys
import glob

os.chdir((__file__).split('split.py')[0]) + 'input/'
a = glob.glob('md_*.pdb')
for file in a:
	num = str(file)[3:-4]
	os.sys('mv 
