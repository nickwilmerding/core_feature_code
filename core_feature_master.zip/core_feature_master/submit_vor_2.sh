#!/bin/bash
#SBATCH --partition=scavenge
#SBATCH --job-name=vor_2
#SBATCH --array=1-1001
#SBATCH -n 1 # 1 tasks
#SBATCH -N 1 # one node
#SBATCH -c 1 # one CPUs/task
#SBATCH -e submit_vor_2.error
#SBATCH -o submit_vor_2.out
#SBATCH --mem-per-cpu=6400
#SBATCH --time=23:59:00
#SBATCH --requeue
# run the command

cd $SLURM_SUBMIT_DIR
sed -n "${SLURM_ARRAY_TASK_ID}p" ./output_vor/process.sh | /bin/bash
