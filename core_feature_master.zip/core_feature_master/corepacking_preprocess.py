#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar  9 16:28:27 2022

@author: nwilmerding
"""

import os
import sys

# generate file with all pdb names and eliminate .pdb extension, $1 is the path to the pdb files#
os.chdir(str(sys.argv[1]))
os.system('python3 print_name.py')
os.system('sed -e s/.pdb//g pdb.txt > pdb2.txt')
os.system('mv pdb2.txt pdb.txt')

# generate ordered pdb files, $2 is the number of pdb files#

os.system('python3 download_preprocess_pdb.py ' + str(sys.argv[1]) + 'pdb.txt ' + str(sys.argv[1]) + ' ' + str(sys.arv[2]) + ' ' + str(sys.argv[1]))

# generate txt files, $3 is the path to vol code on cluster, $4 is the path to pdb folder on cluster#

os.system('bash bash_edge_code_script_local.sh ' + str(sys.argv[1]) + 'pdb.txt ' + str(sys.argv[1]) + ' ' + str(sys.argv[2]) + ' ' + str(sys.argv[3]) + ' ' + str(sys.argv[4]))


#move txt files to a new folder#

os.system('mkdir pdb_txt ; mv *.txt ./pdb_txt')