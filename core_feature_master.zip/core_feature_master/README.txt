## first, place your input .pdb files in /input/ and load a conda environment with biopython installed ##

## next, type: bash ./start ##

## output files will be in /data/ ##
