import os, sys
import glob as glob
a = str(__file__).split('run_generate.py')[0] + 'output_vor/init/'
b = str(__file__).split('run_generate.py')[0]
os.chdir(a)

hiq = open(b+ 'pdb.txt', 'r')
line  = hiq.readlines()
nlines = len(line)
p = []
for i in range(nlines):
        p.append(line[i].split('\n')[0])
hiq.close

f = open('./output_vor/tasklistg.sh','w')

for j in range(nlines):
	Filein = p[j]
	f.write('source ~/.bashrc; cd ' + a + '../../vol_code/' + '; module load MATLAB/2017b; matlab -nosplash -nodisplay -nojvm -r '+'"'+'generate_surface('+"'"+Filein+"', '"+a+"'"+')'+'"'+';\n')
	


