#!/bin/bash
#SBATCH --partition=scavenge
#SBATCH --job-name=vor_4
#SBATCH --array=1-1001
#SBATCH -n 1 # 1 tasks
#SBATCH -N 1 # one node
#SBATCH -c 1 # one CPUs/task
#SBATCH -e submit_vor_4.error
#SBATCH -o submit_vor_4.out
#SBATCH --mem-per-cpu=6400
#SBATCH --time=23:59:00
#SBATCH --requeue
# run the command

python run_generate_10.py

echo "sleep 1m && sbatch submit_pomelo_1.sh" >> ./output_vor/tasklistg_10.sh

cd $SLURM_SUBMIT_DIR
sed -n "${SLURM_ARRAY_TASK_ID}p" ./output_vor/tasklistg_10.sh | /bin/bash
