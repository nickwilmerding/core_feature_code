
import os, sys
import glob as glob
a = str(__file__).split('run_pomelo.py')[0] + 'output_vor/'
os.chdir(a + 'init/')
b = str(__file__).split('run_pomelo.py')[0]

hiq = open(b+ 'pdb.txt', 'r')
line  = hiq.readlines()
nlines = len(line)
p = []
for i in range(nlines):
        p.append(line[i].split('\n')[0])
hiq.close


f = open('../tasklistp.sh','w')

for j in range(nlines):
	pdbname = p[j]
	Filein = a + 'init/' + pdbname + '_param.lua'
	f.write('mkdir ' + a + 'vor_vol/' + pdbname + '_result/ ;' + 'cd ' + b + 'pomelo_code/bin/; ./pomelo -mode GENERIC -i ' + Filein + ' -o ' + a + 'vor_vol/' + pdbname + '_result/ ;\n')
