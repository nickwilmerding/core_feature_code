import os, sys
a = str(__file__).split('move_vol.py')[0] + 'output_vor/vor_vol/'
b = str(__file__).split('move_vol.py')[0] + 'output_vor/vor_vol_10/'
c = str(__file__).split('move_vol.py')[0]
os.chdir(a)

hiq = open(c + 'pdb.txt', 'r')
line  = hiq.readlines()
nlines = len(line)
p = []
for i in range(nlines):
        p.append(line[i].split('\n')[0])
hiq.close

f = open(c + 'output_vor/movelist.sh','w')

for j in range(nlines):
	pdbname = p[j]
	f.write('mv ' + a + pdbname + '_result/setVoronoiVolumes.dat ' + c + 'data/vor_data/' + p[j] + '_vor.txt; \n') 

os.chdir(b)

g = open(c + 'output_vor/movelist_10.sh','w')

for j in range(nlines):
        pdbname	= p[j] 
        g.write('mv ' + b + pdbname + '_result/setVoronoiVolumes.dat ' + c + 'data/vor_data_10/' + p[j] + '_vor.txt; \n')
