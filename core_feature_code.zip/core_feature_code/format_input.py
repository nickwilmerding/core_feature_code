import os,sys
import glob
a = str(__file__)
b = a.split('format_input.py')[0]
list = glob.glob(b + 'input/*.pdb')

for file in list:
        oldname = str(file)
        newname = b + 'input/md' + oldname.split(sys.argv[1])[-1]
        print(newname)
        os.rename(oldname,newname)
