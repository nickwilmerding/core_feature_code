 #!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar  9 16:28:27 2022

@author: nwilmerding
"""

# To run:
# "conda activate $env ; cd $preprocess_dir ; python3 $1 $2 $3 $4"
# $1 = path to ordered input files ~ base/input/MD_#.pdb/
# $2 = (integer) number of ordered input files ~ length {MD_#.pdb}

import os
import sys
pydir = os.getcwd() + '/'

# generate file with all pdb names and eliminate .pdb extension
os.chdir(str(sys.argv[1]))
os.system('python ' + pydir + 'print_name.py')
os.chdir(pydir)
os.system('rm ' + pydir + 'rSASA/pdb/*')


# Add hydrogens to input files

os.system('python ' + pydir + 'download_preprocess_pdb.py ' + pydir + 'input/' + ' ' + pydir + 'pdb.txt ' +  ' ' + str(sys.argv[2]) + ' ' + pydir)

# generate txt files from hydrogenated input; generate tasklist.sh to facilitate batch volume calculation, process.sh to obtain 

os.system('bash bash_edge_code_script_local.sh ' + pydir + 'pdb.txt ' + pydir + 'input/ ' + str(sys.argv[2]) + ' ' + pydir + 'vol_code/' + ' ' + pydir + 'output_vor/')

# move files to appropriate directories

os.system('cp ' + pydir + 'input/*.txt ' + pydir + 'output_vor/init/')
os.system('mv ' + pydir + 'input/*.txt ' + pydir + 'output_vor/init2/')
os.system('mv ' + pydir + 'input/*_H.pdb ' + pydir + 'rSASA/pdb/')
os.system('rm ' + pydir + 'input/*ordered* ')
os.system('rm ' + pydir + 'input/*noH* ')
os.system('mv ' + pydir + 'process.sh ' + pydir + 'output_vor')
os.system('mv ' + pydir + 'tasklist.sh ' + pydir + 'output_vor/')
os.system('sbatch ' + pydir + 'submit_vor_1.sh')
os.system('sbatch ' + pydir + 'submit_rSASA.sh')
