#!/bin/bash
#SBATCH --partition=scavenge
#SBATCH --job-name=rSASA
#SBATCH -N 1 # one node
#SBATCH -c 10 # ten CPUs/task
#SBATCH -e submit_rSASA.error
#SBATCH -o submit_rSASA.out
#SBATCH --mem-per-cpu=6400
#SBATCH --time=23:59:00
#SBATCH --requeue
# run the command

module load MATLAB/2016b
cd ./rSASA/
matlab -nosplash -nodisplay -nojvm -r "database_sasa"
