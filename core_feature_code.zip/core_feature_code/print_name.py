#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 27 21:50:48 2018

@editor: nwilmerding
@author: agrigas
"""
import glob

a = glob.glob('input/*.pdb')

with open('pdb.txt', 'w') as f:
    for item in a:
        f.write("%s\n" % item[6:-4 ])
