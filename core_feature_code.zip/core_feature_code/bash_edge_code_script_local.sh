# Bash script for running edge code 
#bash bash_edge_code_script_local.sh pdb_list.txt folder1 X c1_folder c2_folder

#pdb_list.txt: list of PDB codes, in same folder as this code
#folder1: folder containing PDBs
#X: replace by integer stating number of PDBS in PDB file list
#c1_folder: full path to cluster folder that will contain volume code
#c2_folder: full path to cluster folder that will contain PDB data
# Input :
# 1. name of a file with a list of pdb names. must be full path name
# 2. folder to save everything to
# 3. Number of pdbs to run

# Ouput:
# .txt file for each protein
# Task list for ./vor tasks

# Note:
# All pdb files must already be in the folder
# You must run download_preprocess_pdb.py first to remove heteroatoms and add hydrogens to the proteins

#!/bin/bash 
rm tasklist.sh
rm process.sh

file1=$1 		#File containing list of PBDIB codes
file2="tasklist.sh"
folder_name=$2		#Folder containing PDB files
num_pdb=$3		#Number of PDB to run
cluster_folder=$4	#Folder on cluster where code will be stored
cluster_data=$5		#Folder on cluster where PDBs and output will be
init="init/"
init2="init2/"
init3="init3/"
file3="process.sh"
file_ending4=".pdb"
file_ending5=".txt"
one="1"
space=" "
out="residue_vol/"
vol='_vol'

nfiles=$(ls ./input/ | wc -l)

# Create text files for the proteins
python preprocess_pdb_parameters.py $folder_name $file1 $num_pdb

# Make task list for getting atomic volumes and surface/core designation
while IFS='' read -r line || [[ -n "$line" ]];
	do
		run_loop=1
		echo $line
		line=$(echo "$line" | tr '[:upper:]' '[:lower:]')

		a=($(wc $folder_name$line$file_ending4))
		num_lines=${a[0]}
		num_lines="$(($num_lines - 3))"
		
		while [ $run_loop -le 1 ]
			do
				echo -n "source ~/.bashrc; cd " >> $file2
				echo -n $cluster_folder >> $file2
				echo -n "; ./vor " >> $file2
				echo -n $cluster_data$init >> $file2
				echo -n $line >> $file2
				echo -n "$space" >> $file2
				echo -n $num_lines >> $file2
				echo -n "$space" >> $file2
				echo -n	$run_loop >> $file2
				echo ";" >> $file2
				echo -n " mv $cluster_data$init$line$one$file_ending5 $cluster_data$init3 ; " >> $file2	
				run_loop=$((run_loop+1))
			done
			done<$file1

#Create processing tasks
while IFS='' read -r line || [[ -n "$line" ]];
	do
		run_loop=1
		echo $line
		line=$(echo "$line" | tr '[:upper:]' '[:lower:]')

		a=($(wc $folder_name$line$file_ending4))
		num_lines=${a[0]}
                num_lines="$(($num_lines - 3))"		
		echo -n "source ~/.bashrc; cd " >> $file3
		echo -n $cluster_folder >> $file3
		echo -n '; module load MATLAB/2017b; matlab -nosplash -nodisplay -nojvm -r "process_volume_output(' >> $file3
		echo -n "'" >> $file3
		echo -n $line >> $file3
		echo -n "','" >> $file3
		echo -n $cluster_data$init3 >> $file3
		echo -n "'," >> $file3
		echo -n $num_lines, $nfiles  >> $file3
		echo -n ')"' >> $file3
		echo "; mv $cluster_data$init$line$one$vol$file_ending5 $cluster_data$out$line$one$vol$file_ending5 ; mv $cluster_data$init2*.txt $cluster_data$init ; mv ./output_vor/init3/* ./output_vor/init/ ;" >> $file3
		run_loop=$((run_loop+1))

	echo -/n " mv $cluster_data$init2*.txt $cluster_data$init ;" >>file3
	done<$file1

echo -n "sleep 20m && sbatch $cluster_folder/../submit_vor_2.sh" >> $file2
echo -n "sleep 1m && sbatch $cluster_folder/../submit_vor_3.sh" >> $file3
