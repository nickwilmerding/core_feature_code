positionfile = "../test/2016-02-16_periodicboundarytest/pos.txt"
readfile = "../test/2016-02-16_periodicboundarytest/read.lua"

xmin = -2.0
ymin = -2.0
zmin = -2.0

xmax = 2.0
ymax = 2.0
zmax = 2.0

epsilon = 1e-6

boundary = "periodic"

xpbc = true
ypbc = false 
zpbc = true 

postprocessing = false

