
s = {}

function docalculation (p) 

    p:addpoint(1, -1, 0.5, 0)
    p:addpoint(2, 1, 0, 0)
end
