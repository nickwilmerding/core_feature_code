positionfile = "../test/2015-12-22_onesphere/pos.txt"
readfile = "../test/2015-12-22_onesphere/read.lua"

xmin = 0
ymin = 0
zmin = 0

xmax = 10
ymax = 10
zmax = 10

epsilon = 1e-6

boundary = "none"

postprocessing = false
writepoly = true
