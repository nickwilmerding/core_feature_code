positionfile = "../test/2015-12-16_twopoints/pos.txt"
readfile = "../test/2015-12-16_twopoints/read.lua"

xmin = -2.0
ymin = -2.0
zmin = -2.0

xmax = 2.0
ymax = 2.0
zmax = 2.0

epsilon = 1e-6

boundary = "none"

postprocessing = true

savepoly = true
savereduced = true
savesurface = true
savefe = true
