positionfile = "../test/2016-02-16_periodictwospheres/ellipsoids_linear_std5.ellip"
readfile = "../test/2016-02-16_periodictwospheres/read.lua"

xmin = -3
ymin = -3
zmin = -3

xmax = 3
ymax = 3
zmax = 3

epsilon = 1e-6

boundary = "periodic"

xpbc = true
ypbc = true
zpbc = true

postprocessing = false
