positionfile = "../test/2015-12-17_twospheretest/ellipsoids_linear_std5.ellip"
readfile = "../test/2015-12-17_twospheretest/read.lua"

xmin = -3
ymin = -3
zmin = -3

xmax = 3
ymax = 3
zmax = 3

epsilon = 1e-6

boundary = "none"

postprocessing = false

savepoly = true
savereduced = true
savesurface = true
