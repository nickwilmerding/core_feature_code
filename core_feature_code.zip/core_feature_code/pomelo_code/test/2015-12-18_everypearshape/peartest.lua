positionfile = "../test/2015-12-18_everypearshape/onepear.dat"
readfile = "../test/2015-12-18_everypearshape/read.lua"

xmin = -2
ymin = -5
zmin = -5

xmax = 5
ymax = 5
zmax = 5

boundary = "none"
postprocessing = false

savepoly = true
savereduced = true
savesurface = true
